<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="utf-8">
</head>
<body>
<h3>Welcome {{$name}}</h3>
<div>
    Thank you for signing up.
</div>
</body>
</html>
