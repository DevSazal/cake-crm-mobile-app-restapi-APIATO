<?php

return [

    /*
    |--------------------------------------------------------------------------
    | RazorpaySubscription Container
    |--------------------------------------------------------------------------
    |
    |
    |
    */
    'razorpay' => [
        'key'=>'rzp_test_eHfqdu17WWnG97',
        'secret'=>'7fjNY7GNtuloMNmqe2VuKDtU',
        'active_plans' => ['plan_HCG5IOSRVhZvqm', 'plan_H91htLmC4Ba1Oe']
    ]

];
